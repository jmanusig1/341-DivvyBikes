-- Project0502.sql
-- 2.	Retrieve the number of unique bikeIDs
--
SELECT Count (DISTINCT BikeID) As NumBikes
From Trips
