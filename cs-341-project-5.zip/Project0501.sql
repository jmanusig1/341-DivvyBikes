-- Project0501.sql
-- 1.	Retrieve the number of trips recorded in the database.
SELECT Count (TripID) As NumTrips
From Trips